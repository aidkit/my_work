このディレクトリのファイルは、http://server/jenkins/userContent/ として提供されます。
